package practica3excep;

public class ElectroApp {
public static void main(String[] args) {
	Electrodomestico elec[]=new Electrodomestico [6];
	elec[0]=new Lavadoras(Calif.A, 120,50,120);
	elec[1]=new Lavadoras(Calif.B, 120,50,150);
	elec[2]=new Frigorifico(Calif.A, 120,50);
	elec[3]=new Frigorifico(Calif.B, 120,50);
	elec[4]=new Lavavajillas(Calif.A, 120,50,200);
	elec[5]=new Lavavajillas(Calif.B, 120,50,150);
	
	for (int i = 0; i < elec.length; i++) {
		System.out.println(elec[i].toString());
	}
	elec[1]=null;
	elec[3]=null;
	elec[5]=null;
	System.out.println("-----------------------------------------------------------------------------");
	for (int i = 0; i < elec.length; i++) {
		try {
			System.out.println(elec[i].toString());
		}
		catch(NullPointerException e) {
			System.out.println("Este elemento esta vacio");
		}
	}
}	
}
