package practica3excep;
public enum Calif {
	G,F,E,D,C,B,A
}
